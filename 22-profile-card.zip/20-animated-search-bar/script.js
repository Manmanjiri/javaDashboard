$('#search').focusin(function () {
  $('#Modal').show();
});

$('#close').click(function () {
  $('#Modal').hide();
});
