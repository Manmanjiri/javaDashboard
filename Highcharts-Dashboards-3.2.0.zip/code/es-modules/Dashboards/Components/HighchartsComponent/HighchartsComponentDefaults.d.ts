import type Globals from '../../Globals';
import type Options from './HighchartsComponentOptions';
declare const HighchartsComponentDefaults: Globals.DeepPartial<Options>;
export default HighchartsComponentDefaults;
