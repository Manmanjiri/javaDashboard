import type Globals from '../../Globals';
import type Options from './KPIComponentOptions';
declare const KPIComponentDefaults: Globals.DeepPartial<Options>;
export default KPIComponentDefaults;
