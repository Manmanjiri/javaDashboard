import type Globals from '../../Globals';
import type Options from './HTMLComponentOptions';
declare const HTMLComponentDefaults: Globals.DeepPartial<Options>;
export default HTMLComponentDefaults;
