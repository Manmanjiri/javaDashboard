import type Globals from '../../Globals';
import type Options from './DataGridComponentOptions';
declare const DataGridComponentDefaults: Globals.DeepPartial<Options>;
export default DataGridComponentDefaults;
