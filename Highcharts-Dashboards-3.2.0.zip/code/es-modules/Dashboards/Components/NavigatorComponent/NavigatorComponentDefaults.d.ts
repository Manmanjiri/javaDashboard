import type Globals from '../../Globals';
import type Options from './NavigatorComponentOptions';
declare const NavigatorComponentDefaults: Globals.DeepPartial<Options>;
export default NavigatorComponentDefaults;
