import MenuItem from './MenuItem.js';
declare const MenuItemBindings: Record<string, MenuItem.Options>;
export default MenuItemBindings;
