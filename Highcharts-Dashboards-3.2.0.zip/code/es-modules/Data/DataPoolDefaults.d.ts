import type DataPoolOptions from './DataPoolOptions.js';
declare const DataPoolDefaults: DataPoolOptions;
export default DataPoolDefaults;
