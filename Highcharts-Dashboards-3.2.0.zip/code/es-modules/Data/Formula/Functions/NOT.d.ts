import type { Arguments } from '../FormulaTypes';
import type DataTable from '../../DataTable.js';
/**
 * Processor for the `NOT(value)` implementation. Returns the opposite test
 * result.
 *
 * @private
 * @function Formula.processorFunctions.NOT
 *
 * @param {Highcharts.FormulaArguments} args
 * Arguments to process.
 *
 * @param {Highcharts.DataTable} [table]
 * Table to use for references and ranges.
 *
 * @return {boolean|number}
 * Result value of the process.
 */
declare function NOT(args: Arguments, table?: DataTable): (boolean | number);
export default NOT;
