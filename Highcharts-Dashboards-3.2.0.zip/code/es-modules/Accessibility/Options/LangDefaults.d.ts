import type LangOptions from './LangOptions';
declare const langOptions: DeepPartial<LangOptions>;
export default langOptions;
