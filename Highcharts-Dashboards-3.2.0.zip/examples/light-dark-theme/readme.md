# Light dark theme detection
The CSS module `dashboards.css` contains default styling for light and dark modes. This allows the user to style the dashboard based on the theme selected on the user's machine.
If your dashboard contains Highcharts charts, you have to enable the styled mode.

To test it, please change the default theme in your computer options.
