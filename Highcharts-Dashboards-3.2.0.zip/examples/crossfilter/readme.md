# Crossfilter with RangeModifier
You can apply a RangeModifier on the main connector of the data pool to
cross-filter large data sets for a better overview in a DataGrid. The axis
extremes of each navigator define the value range for one of the columns.
